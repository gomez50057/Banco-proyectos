# admin.py

from django.contrib import admin
# from .models import ProyectoDependencia
from .models import Project


# admin.site.register(ProyectoDependencia)
admin.site.register(Project)
